
function toggleMenu(){
  const menu = document.getElementById('menu');
  if(menu.style.display==='flex'){menu.style.display='none';}
  else{menu.style.display='flex';}
}
document.addEventListener('DOMContentLoaded',()=>{
  const y = document.getElementById('year');
  if(y){ y.textContent = new Date().getFullYear(); }
});
