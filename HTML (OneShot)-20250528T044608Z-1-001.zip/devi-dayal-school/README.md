# Devi Dayal Sr. Sec. Sanskrit School — Website

## Folder structure
- `index.html` — Home
- `about.html`
- `gallery.html`
- `admission.html`
- `contact.html`
- `style.css`
- `script.js`
- `images/` — logo & photos

## How to host on GitHub Pages
1. Create a new repository (e.g., `ddsss-website`).
2. Upload all files from this folder (keep the structure as it is).
3. Go to **Settings → Pages → Source → `main` branch → `/root`** and click **Save**.
4. Wait a moment, then your site will be live at: `https://<your-username>.github.io/ddsss-website/`

You can edit HTML/CSS any time and push again.
